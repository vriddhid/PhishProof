from flask import Flask,render_template,request,redirect,url_for,session
import sqlite3
import requests
import pandas as pd
from urllib.parse import urlparse
import pickle
from extractdef import *
import whois

app = Flask(__name__)
app.secret_key = "youcanDOthis42"

def extract_features(url):
    
    domain = urlparse(url).netloc
    if re.match(r"^www.",domain): domain = domain.replace("www.","")
    
    features = []
  #Address bar based features (10)
    features.append(havingIP(url))
    features.append(haveAtSign(url))
    features.append(getLength(url))
    features.append(getDepth(url))
    features.append(redirection(url))
    features.append(httpDomain(url))
    features.append(tinyURL(url))
    features.append(prefixSuffix(url))
  
  #Domain based features (4)
    dns = 0
    try:
        domain_name = whois.whois(urlparse(url).netloc)
    except:
        dns = 1

    features.append(dns)
    features.append(1 if dns == 1 else domainAge(domain_name))
    features.append(1 if dns == 1 else domainEnd(domain_name))
  
  # HTML & Javascript based features (4)
    try:
        response = requests.get(url)
    except:
        response = ""
    features.append(iframe(response))
    features.append(mouseOver(response))
    features.append(rightClick(response))
    features.append(forwarding(response))
    #features.append(label)


    feature_names = ['Have_IP', 'Have_At', 'URL_Length', 'URL_Depth',
       'Redirection', 'https_Domain', 'TinyURL', 'Prefix/Suffix', 'DNS_Record',
       'Domain_Age', 'Domain_End', 'iFrame', 'Mouse_Over', 'Right_Click', 'Web_Forwards']
    
    df = pd.DataFrame([features], columns=feature_names)
    
    return df

def predict_class(url):
    model = pickle.load(open('../mlp.pkl', 'rb'))
    url_features = extract_features(url)
    features_final = url_features.values.reshape(1, -1)
    print(features_final)
    prediction = model.predict(url_features)
    print(prediction)
    return "legitimate webpage" if prediction == 0 else "Caution: The website you are attempting to access may be a phishing site. Be careful not to share any sensitive information."

@app.route("/")
def index():
    return render_template('index.html')


def validate(username, password):
    conn = sqlite3.connect('../database.db')
    cur = conn.cursor()

    cur.execute('CREATE TABLE IF NOT EXISTS user (username TEXT, password TEXT);')
    conn.commit()

    cur.execute('SELECT * FROM user;')
    data = cur.fetchall()
    flag = 0
    for USER, PASS in data:
        if USER == username:
            flag = 1
            if PASS == password:
                return 1
            else:
                break

    if flag != 1:
        cur.execute('INSERT INTO user VALUES (?, ?)', (username, password))
        conn.commit()
        conn.close()
        return 1

    conn.close()
    return 0


@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        username = request.form['user']
        password = request.form['pass']

        if username == '' or password == '':
            return redirect(url_for('index'))
        
        if validate(username, password):
            session['user'] = username
            return redirect(url_for('classification'))
        else:
            return redirect(url_for('index'))
        
    else:
        return render_template('index.html')


@app.route("/classification", methods=["POST", "GET"])
def classification():
    if 'user' in session:
        if request.method == "POST":
                url = request.form['url']           
                prediction = predict_class(url)
                result = f'url : {prediction}'
                return render_template('classification.html', prediction=result, user=session['user'])

            
        else:
            return render_template('classification.html',user=session['user'])
    return redirect(url_for('index'))



@app.route("/logout")
def logout():
    if "user" in session:
        session.pop("user", None)
    return redirect(url_for('index'))